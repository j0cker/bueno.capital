(function() {
  app.controller('index', function($scope, functions, $window) {

    functions.loading();

    console.log("[IndexCtrl]");

  });


  return;

}).call(this);
